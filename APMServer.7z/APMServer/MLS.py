__author__ = 'Jose Antonio Fernandez Casillas'

from Server import Server

test = Server("udp:192.168.1.135:14550")