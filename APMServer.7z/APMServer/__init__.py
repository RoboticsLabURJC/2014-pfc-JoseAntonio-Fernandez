__author__ = 'Jose Antonio Fernandez Casillas'


from Server import Server

test = Server("/dev/ttyUSB0", 57600)